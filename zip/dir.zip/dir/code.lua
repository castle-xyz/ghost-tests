local code = {}


function code.foo()
    return 'bar'
end


return code
